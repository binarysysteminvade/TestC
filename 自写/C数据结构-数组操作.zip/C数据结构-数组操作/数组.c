#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Arr
{
	int * pBase;
	int len;
	int cnt;
}Arrary,* Parrary;

void init_arrary(Parrary arr, int len);
bool append_arrary(Parrary arr, int val);
bool is_full(Parrary arr);
bool show_arrary(Parrary arr);
bool is_empty(Parrary arr);
bool insert_arrary(Parrary arr, int pos, int val);
bool delete_arrary(Parrary arr, int pos, int *val);
bool inversion_arr(Parrary arr);
bool sort_arr(Parrary arr);

int main(void)
{
	Arrary arr;
	init_arrary(&arr, 6);
	append_arrary(&arr, 11);
	append_arrary(&arr, 23);
	append_arrary(&arr, 355);
	append_arrary(&arr, 41);
	append_arrary(&arr, 52);
	show_arrary(&arr);
	insert_arrary(&arr, 6, 6);
	show_arrary(&arr);
	int a;
	delete_arrary(&arr, 3, &a);
	printf("ɾ����ֵ: %d\n", a);
	show_arrary(&arr);
	printf("����: "); 
	inversion_arr(&arr);
	show_arrary(&arr);
	printf("����: "); 
	sort_arr(&arr);
	show_arrary(&arr);
	return 0;
}

void init_arrary(Parrary arr, int len) 
{
	arr->pBase = (int *)malloc(sizeof(int)*len);
	arr->len = len;
	arr->cnt = 0;
	return ;
}

bool is_full(Parrary arr)
{
	if (arr->cnt == arr->len)
		return true;
	else
		return false;
}

bool append_arrary(Parrary arr, int val)
{
	if (is_full(arr))
		return false;
	arr->pBase[arr->cnt] = val;
	arr->cnt++;
	return true;
}

bool show_arrary(Parrary arr)
{		
	if (is_empty(arr))
		return false;
	unsigned int i;
	for (i = 0; i < arr->cnt; i++) 
	{
		printf("%d ", arr->pBase[i]);
	}
	printf("\n");
	return true;
}

bool is_empty(Parrary arr)
{
	if (arr->cnt == 0)
		return true;
	else
		return false;
}


bool insert_arrary(Parrary arr, int pos, int val)
{
	if (is_full(arr))
	{
		printf("�����Ѿ�����!!!\n"); 
		return false;
	}
	if (pos < 1 || pos > arr->cnt+1)
	{
		printf("����ʱС��1, ����������벻����\n");
		return false; 
	}
	int i;
	for (i = arr->cnt -1; i >= pos -1; i--)
	{
		arr->pBase[i+1] = arr->pBase[i];
	}
	arr->pBase[pos-1] = val;
	arr->cnt++;
	return true;
}

bool delete_arrary(Parrary arr, int pos, int *val)
{
	if (is_empty(arr))
		return false;
	if (pos < 1 || pos > arr->cnt)
		return false;
	int i;
	*val = arr->pBase[pos -1];
	for (i = pos; i < arr->cnt; i++)
	{
		arr->pBase[i-1] = arr->pBase[i];//pBase[i-1] ��Ҫɾ����ֵ Ȼ����ǰŲʵ��ɾ�� 
	} 
	arr->cnt--; 
	return true;
}

bool inversion_arr(Parrary arr)
{
	int i = 0;
	int j = arr->cnt-1;
	int t;
	while (i < j)
	{
		t = arr->pBase[i];
		arr->pBase[i] = arr->pBase[j];
		arr->pBase[j] = t;
		i++;
		j--;
	}
	return true;
} 

bool sort_arr(Parrary arr)
{
	int i, j, t;
	for (i = 0; i < arr->cnt; i++)
	{
		for (j = i+1; j < arr->cnt; j++)
		{
			if (arr->pBase[i] > arr->pBase[j])
			{
				t = arr->pBase[i];
				arr->pBase[i] = arr->pBase[j];
				arr->pBase[j] = t;
			}
		}
	}
	return true;
}
